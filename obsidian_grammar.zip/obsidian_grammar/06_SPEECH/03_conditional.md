# 💬 Условное наклонение (Conditionals)

## 🧭 Где мы?
[[../00_CORE/00_INDEX|← Индекс]] → **Речь → Условные предложения**

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 Запомни
> Четыре типа условных предложений — от реального к невозможному.
> Чем нереальнее условие → тем «дальше в прошлое» уходит глагол.

---

## 📊 Четыре типа Conditionals

### Type 0 — Всегда истинно (факты, законы)
**Формула:** `If + Present Simple → Present Simple`

> `If you heat water to 100°C, it **boils**.`
> Если нагреть воду до 100°C, она закипает.

---

### Type 1 — Реальное условие (вероятно в будущем)
**Формула:** `If + Present Simple → will + инфинитив`

> `If it **rains**, I **will stay** home.`
> Если пойдёт дождь, я останусь дома.

> [!WARNING] После `if` — Present Simple, НЕ will!
> ✅ `If she **comes**, I will tell her.`
> ❌ `If she **will come**, I will tell her.`

---

### Type 2 — Нереальное условие (маловероятно или невозможно сейчас)
**Формула:** `If + Past Simple → would + инфинитив`

> `If I **were** you, I **would speak** to him.`
> На твоём месте я бы поговорил с ним.
>
> `If she **had** more time, she **would learn** French.`
> Если бы у неё было больше времени, она бы учила французский.

> [!NOTE] Глагол `be` в Type 2 → всегда **were** для всех лиц
> `If I **were** rich…` (не *was*) — классическая норма
> В разговорной речи `If I was rich…` тоже допустимо.

---

### Type 3 — Невозможное условие (в прошлом — уже не изменить)
**Формула:** `If + Past Perfect → would have + III форма`

> `If I **had known**, I **would have helped**.`
> Если бы я знал, я бы помог. (но не знал — и не помог)
>
> `If she **hadn't been** late, she **would have caught** the train.`
> Если бы она не опоздала, она бы успела на поезд.

---

## 📊 Сводная таблица

| Тип | Условие | If-часть | Главная часть | Реальность |
|---|---|---|---|---|
| **0** | Факт/закон | Present Simple | Present Simple | Всегда |
| **1** | Реально | Present Simple | will + V | Вероятно |
| **2** | Нереально сейчас | Past Simple | would + V | Маловероятно |
| **3** | Нереально в прошлом | Past Perfect | would have + V3 | Невозможно |

---

## 📌 Другие способы выразить условие

| Слово | Значение | Пример |
|---|---|---|
| **unless** | если не | `Unless you hurry, you'll be late.` |
| **provided (that)** | при условии, что | `I'll come provided you invite me.` |
| **as long as** | пока / при условии | `You can stay as long as you're quiet.` |
| **suppose / supposing** | предположим, что | `Suppose you won the lottery…` |
| **wish** | желание (нереальное) | `I wish I **were** taller.` / `I wish I **had studied** harder.` |

> [!NOTE] `wish` + время
> `I wish I **were**…` — нереальное желание о настоящем (Type 2)
> `I wish I **had done**…` — сожаление о прошлом (Type 3)
> `I wish you **would stop**…` — раздражение по поводу привычки

---

## 🧠 Проверь себя

1. If it ___ (rain) tomorrow, we ___ (stay) inside. (Type 1)
2. If I ___ (be) you, I ___ (apologise). (Type 2)
3. If she ___ (study) harder, she ___ (pass) the exam. (Type 3)

<details>
<summary>👀 Ответы</summary>
1. If it rains, we will stay inside.<br>
2. If I were you, I would apologise.<br>
3. If she had studied harder, she would have passed the exam.
</details>

---

> [!CHECKBOX] ✅ Чеклист
> - [ ] Type 1: if + Present Simple → will (реальное будущее)
> - [ ] Type 2: if + Past Simple → would (нереально сейчас)
> - [ ] Type 3: if + Past Perfect → would have + V3 (нереально в прошлом)
> - [ ] После if — никогда не ставим will
> - [ ] wish + Past Simple = нереальное желание о настоящем
