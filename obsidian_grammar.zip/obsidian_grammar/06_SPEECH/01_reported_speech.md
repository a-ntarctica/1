# 💬 Косвенная речь (Reported Speech)

## 🧭 Где мы?
[[../00_CORE/00_INDEX|← Индекс]] → **Речь → Косвенная речь**

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 Запомни
> Косвенная речь = пересказ чужих слов.
> Главное правило: **всё сдвигается в прошлое** (если глагол пересказа в прошедшем).
> `"I am tired."` → `He said he **was** tired.`

---

## 📊 Сдвиг времён

| Прямая речь | Косвенная речь |
|---|---|
| Present Simple `"I play"` | Past Simple `he said he **played**` |
| Present Continuous `"I am playing"` | Past Continuous `he said he **was playing**` |
| Present Perfect `"I have played"` | Past Perfect `he said he **had played**` |
| Past Simple `"I played"` | Past Perfect `he said he **had played**` |
| Future `"I will play"` | Future in the Past `he said he **would play**` |

> [!NOTE] Исключение: общеизвестные факты не сдвигаются
> `The teacher said that the Earth **is** round.` — Земля круглая (всегда)

---

## 📊 Сдвиг слов и выражений

| Прямая речь | Косвенная речь |
|---|---|
| `this` | `that` |
| `these` | `those` |
| `here` | `there` |
| `now` | `then` |
| `today` | `that day` |
| `yesterday` | `the day before` |
| `tomorrow` | `the next day` |
| `last week` | `the previous week` |
| `two days ago` | `two days before` |
| `this week` | `that week` |

---

## 📜 Типы косвенной речи

### Утверждения → `said (that)` / `told smb (that)`

> `"I am tired."` → `She said (that) she **was** tired.`
> `"I will help you."` → `He told me he **would** help me.`

### Общие вопросы → `asked if / whether`

> `"Do you like coffee?"` → `She asked **if** I liked coffee.`
> `"Will he come?"` → `I asked **whether** he would come.`
> ❗ Порядок слов — как в утверждении, без вспомогательного глагола вперёд.

### Специальные вопросы → вопросительное слово + порядок утверждения

> `"Where do you live?"` → `He asked **where** I **lived**.`
> `"What happened?"` → `She asked **what had happened**.`
> ❌ `He asked where did I live.` — ошибка!

### Просьбы и приказы → `asked/told + to + инфинитив`

> `"Go to the board."` → `The teacher told the pupil **to go** to the board.`
> `"Don't be late."` → `She asked him **not to be** late.`

---

## 🧠 Проверь себя

Переведи в косвенную речь:
1. `"I am busy."` — He said ___
2. `"Do you speak French?"` — She asked me ___
3. `"Come here!"` — He told me ___

<details>
<summary>👀 Ответы</summary>
1. He said he was busy.<br>
2. She asked me if I spoke French.<br>
3. He told me to come there.
</details>

---

→ [[02_sequence_of_tenses|Согласование времён →]]

> [!CHECKBOX] ✅ Чеклист
> - [ ] Времена сдвигаются на шаг назад
> - [ ] this/here/now/today → that/there/then/that day
> - [ ] Вопросы → if/whether (общий) или вопр. слово (спец.) + порядок утверждения
> - [ ] Приказы → told/asked + to + инфинитив
