# 💬 Согласование времён (Sequence of Tenses)

## 🧭 Где мы?
[[../00_CORE/00_INDEX|← Индекс]] → [[01_reported_speech|← Косвенная речь]] → **Согласование времён**

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 Запомни
> Если глагол главного предложения стоит в **прошедшем времени** —
> глагол придаточного **тоже переходит в прошедшее**.
> `I know that she **is** ready.` → `I **knew** that she **was** ready.`

---

## 📊 Правила согласования

| Ситуация в придаточном | Время в придаточном | Пример |
|---|---|---|
| Одновременно с главным | Past Simple / Past Continuous | `I knew you **were** ready.` |
| Раньше главного | Past Perfect | `I didn't know he **had gone**.` |
| Конкретное время в прошлом | Past Simple | `I knew you **were** in cinema yesterday.` |
| Будущее с точки зрения прошлого | Future in the Past (would) | `I knew he **would come**.` |

---

## 📌 Исключения — время НЕ сдвигается

> [!WARNING] Общеизвестные факты и законы природы
> `The teacher said that water **boils** at 100°C.` ✅
> `Scientists proved that the Earth **revolves** around the Sun.` ✅

> [!WARNING] Конкретная дата или время остаётся
> `She said the meeting **was** on Monday.` — дата остаётся неизменной

---

## 📊 Future in the Past — «будущее в прошедшем»

> Когда нужно выразить будущее действие с точки зрения прошлого:

| Прямая речь | Косвенная речь |
|---|---|
| `will` | `would` |
| `shall` | `should` |
| `am/is/are going to` | `was/were going to` |

`"I will help you."` → `He said he **would** help me.`
`"We are going to leave."` → `She said they **were going to** leave.`

---

## 🧠 Проверь себя

Согласуй времена:
1. I think she ___ (is) ready. → I thought she ___ ready.
2. He says he ___ (will come). → He said he ___ come.
3. She told me she ___ (has already finished). → She told me she ___ already ___.

<details>
<summary>👀 Ответы</summary>
1. I thought she was ready.<br>
2. He said he would come.<br>
3. She told me she had already finished.
</details>

---

> [!CHECKBOX] ✅ Чеклист
> - [ ] Главное в прошедшем → придаточное тоже в прошедшем
> - [ ] Общеизвестные факты → время не меняется
> - [ ] will → would | is → was | has done → had done
