# 👤 Неопределённые местоимения: some / any / every / no

## 🧭 Где мы?
[[../00_CORE/00_INDEX|← Индекс]] → [[01_personal|← Личные]] → **Неопределённые местоимения**

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 Запомни
> Четыре корня × три окончания = 12 слов. Учи как таблицу умножения.
>
> `some` → утверждение | `any` → вопрос/отрицание | `every` → всё/все | `no` → ничего/никого

---

## 📊 Таблица: корень × окончание

| | **-body** (люди) | **-thing** (предметы) | **-where** (место) |
|---|---|---|---|
| **some-** | somebody / someone | something | somewhere |
| **any-** | anybody / anyone | anything | anywhere |
| **every-** | everybody / everyone | everything | everywhere |
| **no-** | nobody / no one | nothing | nowhere |

---

## 📜 Когда что использовать

> [!WARNING] **some** — утверждения + просьбы/предложения
> `I saw **somebody** in the garden.` — Я видел кого-то в саду.
> `There is **something** on the table.` — На столе что-то есть.
> `Can I have **some** tea?` — Можно мне чаю? (просьба → some, не any)
> `Would you like **something** to eat?` — Хочешь что-нибудь поесть? (предложение)

> [!WARNING] **any** — вопросы + отрицания + «любой»
> `Do you have **anything** to say?` — Тебе есть что сказать?
> `I didn't see **anybody**.` — Я никого не видел.
> `Take **any** book you like.` — Возьми любую книгу. (= любую из всех)

> [!WARNING] **every** — «каждый», «всё», «везде»
> `**Everybody** knows this.` — Все это знают.
> `**Everything** is ready.` — Всё готово.
> `I looked **everywhere**.` — Я искал везде.

> [!WARNING] **no** — отрицание без `not` (само по себе)
> `**Nobody** came.` — Никто не пришёл.
> `I know **nothing** about it.` — Я ничего не знаю об этом.
> ❗ С `no`-словами глагол стоит в **утвердительной** форме — двойного отрицания нет!
> ✅ `Nobody **came**.` ❌ `Nobody **didn't come**.`

---

## 📊 Простые неопределённые местоимения

| Местоимение | С чем | Пример |
|---|---|---|
| **much** (много) | неисчисляемые | `I don't have much time.` |
| **many** (много) | исчисляемые | `She told me many stories.` |
| **little** (мало) | неисчисляемые | `I have little time today.` |
| **few** (мало) | исчисляемые | `Few people know this.` |
| **a little** (немного) | неисчисляемые | `Add a little salt.` |
| **a few** (несколько) | исчисляемые | `I have a few questions.` |
| **a lot of** (много) | оба типа | `A lot of people / A lot of water.` |
| **each** (каждый, по одному) | исчисляемые ед.ч. | `Each pupil answered.` |
| **every** (каждый, все вместе) | исчисляемые ед.ч. | `Every pupil answered.` |
| **both** (оба) | мн. число (о двух) | `Both answers are correct.` |
| **either** (любой из двух) | ед. число | `Take either road.` |
| **neither** (ни тот, ни другой) | ед. число | `Neither answer is correct.` |

> [!NOTE] little/few vs a little/a few
> Без артикля — **почти нет** (негативный оттенок):
> `I have little money.` — У меня почти нет денег. 😟
> С артиклем — **есть немного** (позитивный оттенок):
> `I have a little money.` — У меня есть немного денег. 🙂

---

## 🧠 Проверь себя

Вставь нужное слово:
1. Is there ___ in the room? (кто-нибудь)
2. I didn't eat ___. (ничего)
3. She has ___ friends in this city. (почти нет)
4. ___ knows the answer. (все)

<details>
<summary>👀 Ответы</summary>
1. anybody/anyone | 2. anything (I didn't eat anything) | 3. few friends | 4. Everybody/Everyone
</details>

---

→ [[03_other|Указательные и вопросительные →]]

> [!CHECKBOX] ✅ Чеклист
> - [ ] some → утверждения и вежливые просьбы/предложения
> - [ ] any → вопросы, отрицания, «любой»
> - [ ] no-слова → без not, глагол в утвердительной форме
> - [ ] little/few (почти нет) vs a little/a few (немного есть)
> - [ ] much/little → неисчисляемые | many/few → исчисляемые
