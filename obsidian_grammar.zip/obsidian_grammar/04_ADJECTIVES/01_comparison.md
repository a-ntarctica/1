# 🎨 Степени сравнения прилагательных и наречий

## 🧭 Где мы?
[[../00_CORE/00_INDEX|← Индекс]] → **Прилагательные → Степени сравнения**

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 Запомни
> Три степени: **положительная → сравнительная → превосходная**
> `big → bigger → the biggest`
> `beautiful → more beautiful → the most beautiful`

---

## 📜 Прилагательные

### Правило 1: Короткие (1–2 слога) → **+er / +est**

| Условие | Правило | Пример |
|---|---|---|
| Обычно | **+er / +est** | `new → newer → newest` |
| На **-e** | **+r / +st** | `nice → nicer → nicest` |
| Согл. + **-y** | **-y → -ier / -iest** | `happy → happier → happiest` |
| Краткий слог + согл. | удвоить + **er/est** | `big → bigger → biggest` |
| На **-er, -ow, -le** | **+er / +est** | `clever → cleverer → cleverest` |

### Правило 2: Длинные (3+ слога) → **more / most**

`beautiful → more beautiful → the most beautiful`
`interesting → more interesting → the most interesting`

---

## 🚨 Исключения — учить отдельно

| Положительная | Сравнительная | Превосходная |
|---|---|---|
| good | better | the best |
| bad | worse | the worst |
| far (расстояние) | farther | the farthest |
| far (расстояние/время) | further | the furthest |
| near | nearer | the nearest / next |
| late (время) | later | the latest |
| late (порядок) | latter | the last |
| old (возраст) | older | the oldest |
| old (в семье) | elder | the eldest |
| little | less | the least |
| much / many | more | the most |

> [!NOTE] older vs elder
> `elder` используется только для **членов семьи**:
> `my **elder** brother` — мой старший брат
> `He is **older** than me.` — Он старше меня. (сравнение в общем)

---

## 📜 Наречия

### Короткие → **+er / +est**
`fast → faster → fastest` | `hard → harder → hardest`

### Длинные → **more / most**
`slowly → more slowly → most slowly`
`beautifully → more beautifully → most beautifully`

### Исключения
| Положительная | Сравнительная | Превосходная |
|---|---|---|
| well | better | best |
| badly | worse | worst |
| far | farther / further | farthest / furthest |
| little | less | least |
| much | more | most |

---

## 📌 Конструкции сравнения

| Конструкция | Значение | Пример |
|---|---|---|
| **as … as** | такой же … как | `She is as tall as her sister.` |
| **not as … as** | не такой … как | `He is not as fast as me.` |
| **than** | чем | `She is taller than her sister.` |
| **the … the …** | чем … тем … | `The sooner, the better.` |

---

## 🧠 Проверь себя

1. This is ___ (хороший → превосходная) film I've ever seen.
2. She runs ___ (быстро → сравнительная) than me.
3. ___ you practice, ___ you improve. (чем … тем)

<details>
<summary>👀 Ответы</summary>
1. the best film | 2. faster than me | 3. The more you practice, the more you improve.
</details>

---

> [!CHECKBOX] ✅ Чеклист
> - [ ] Короткие прил.: +er/+est | Длинные: more/most
> - [ ] Исключения: good/better/best, bad/worse/worst
> - [ ] elder = члены семьи | older = общее сравнение
> - [ ] as…as = одинаково | than = сравнение | the…the = чем…тем
