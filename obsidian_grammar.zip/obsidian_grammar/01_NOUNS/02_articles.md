# 📦 Артикли: a / an / the / —

## 🧭 Где мы?
[[../00_CORE/00_INDEX|← Индекс]] → **Существительные → Артикли**

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 Запомни
> - **a / an** — говорим о чём-то впервые или неизвестном («какой-то»)
> - **the** — говорим о конкретном, уже известном («тот самый»)
> - **—** (без артикля) — абстракции, имена, дни недели и другие исключения

---

## 📜 Определённый артикль **the**

| Случай | Пример |
|---|---|
| Единственный в своём роде | `the sun, the moon, the earth` |
| Уже упоминался раньше | `I saw a dog. The dog was big.` |
| Моря, океаны, реки | `the Pacific, the Nile` |
| Горные цепи, регионы | `the Alps, the Caucasus, the Crimea` |
| Порядковые числительные | `on the first floor` |
| Превосходная степень | `the biggest building` |
| Стороны света | `the North, the East` |
| Фамилия во мн. числе (семья) | `the Petrovs` |
| Достопримечательности, музеи, газеты | `the Kremlin, the British Museum` |
| Некоторые страны | `the USA, the UK` |

### 📌 Устойчивые выражения с **the**
```
to play the piano / violin        — играть на пианино / скрипке
to go to the theatre / cinema     — ходить в театр / кино
in the morning / afternoon / evening — утром / днём / вечером
in the street                     — на улице
to tell the truth                 — сказать правду
in the distance                   — вдали
```

---

## 📜 Неопределённый артикль **a / an**

> [!NOTE] **a** — перед согласным звуком | **an** — перед гласным звуком
> `a dog` | `a university` [ju…] | `an apple` | `an hour` [aʊ…]

| Случай | Пример |
|---|---|
| Профессия | `My sister is a doctor.` |
| После `there is / was / will be` | `There is a pool in our garden.` |
| Восклицание | `What a nice evening!` |
| После `such` | `It was such a wonderful day!` |
| Время, вес, расстояние | `I'll be there in a minute.` |
| Любой предмет из класса | `Take a pencil, please.` |
| Незнакомый человек | `A man wants to see you.` |

### 📌 Устойчивые выражения с **a**
```
to have a look       — взглянуть
to go for a walk     — пойти на прогулку
to be in a hurry     — спешить
to be at a loss      — растеряться
to have a headache   — болеть голова
as a matter of fact  — собственно говоря
```

---

## 📜 Без артикля **—**

| Случай | Пример |
|---|---|
| Мн. число → класс предметов | `These are good flowers.` |
| Абстрактные понятия (в общем) | `Life is beautiful.` |
| Завтрак / обед / ужин | `We have lunch at noon.` |
| `bed, school, town, sea` с предлогами | `to go to bed / to school` |
| Имена собственные | `Moscow, France, Anna` |
| Дни недели и месяцы | `Monday, January` |
| Члены семьи внутри семьи | `Father, can you help me?` |

---

## 🧠 Проверь себя

Вставь a / the / — :
1. ___ sun rises in the east.
2. She is ___ engineer.
3. We go to ___ school every day.
4. What ___ beautiful day!

<details>
<summary>👀 Ответы</summary>
1. The sun | 2. an engineer | 3. — school | 4. What a beautiful day!
</details>

---

> [!CHECKBOX] ✅ Чеклист
> - [ ] the = конкретный / ранее упомянутый / единственный в роде
> - [ ] a/an = впервые / любой из класса / профессия
> - [ ] без артикля = абстракция, имена, дни, еда, члены семьи
