# 📦 Множественное число существительных

## 🧭 Где мы?
[[../00_CORE/00_INDEX|← Индекс]] → **Существительные → Множественное число**

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 Запомни
> Большинство существительных просто получают **+s**.
> Остальное — правила и исключения ниже.

---

## 📜 Основные правила

| Окончание слова | Что делаем | Пример |
|---|---|---|
| Согласный или немая **-e** | **+s** | `dog→dogs`, `name→names` |
| **-ss, -x, -sh, -ch, -o** | **+es** | `box→boxes`, `brush→brushes`, `church→churches`, `tomato→tomatoes` |
| Согласная + **-y** | **-y → -ies** | `baby→babies`, `city→cities` |
| Гласная + **-y** | **+s** | `day→days`, `key→keys` |
| **-f / -fe** | **→ -ves** | `knife→knives`, `wife→wives`, `wolf→wolves` |

---

## 🚨 Исключения — учить отдельно

### Одинаковая форма ед. и мн. числа
`deer — deer` | `sheep — sheep` | `swine — swine`

### Изменение гласной в корне
| Ед. число | Мн. число |
|---|---|
| man | men |
| woman | women |
| tooth | teeth |
| foot | feet |
| goose | geese |
| mouse | mice |

### Нестандартные окончания
| Ед. число | Мн. число |
|---|---|
| child | children |
| ox | oxen |

### Только множественное число
`trousers` `glasses` `clothes` `scissors` `goods` `spectacles`

### Только единственное число
`sugar` `milk` `money` `weather` `peace`

---

## 🧠 Проверь себя

1. knife → ___ | 2. woman → ___ | 3. city → ___ | 4. sheep → ___

<details>
<summary>👀 Ответы</summary>
1. knives | 2. women | 3. cities | 4. sheep
</details>

---

→ [[02_articles|Артикли →]]

> [!CHECKBOX] ✅ Чеклист
> - [ ] Базовые правила (+s, +es, -y→-ies, -f→-ves)
> - [ ] Исключения с изменением корня
> - [ ] Слова только во мн. числе
