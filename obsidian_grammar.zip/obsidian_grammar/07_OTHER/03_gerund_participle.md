# 📎 Герундий и причастие

## 🧭 Где мы?
[[../00_CORE/00_INDEX|← Индекс]] → **Дополнительно → Герундий и причастие**

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 Запомни
> Обе формы выглядят похоже, но выполняют разные роли:
> **Герундий** (-ing) = существительное («плавание полезно»)
> **Причастие** (-ing / -ed) = прилагательное или деепричастие («плывущий», «сделав»)

---

## 📜 Герундий (Gerund)

> Глагол в роли **существительного**. Заканчивается на **-ing**.

### Формы герундия

| Форма | Образование | Пример |
|---|---|---|
| Простой (Indefinite) | основа + **-ing** | `asking` — спрашивание |
| Перфектный (Perfect) | **having** + III форма | `having asked` — то, что спросил |
| Пассивный (Passive) | **being** + III форма | `being asked` — то, что спрашивают |

### Роли герундия в предложении

| Роль | Пример | Перевод |
|---|---|---|
| Подлежащее | `**Reading** is useful.` | Чтение полезно. |
| Дополнение | `Nobody likes **waiting**.` | Никто не любит ждать. |
| Часть сказуемого | `Your job was **collecting** data.` | Твоей задачей был сбор данных. |
| Определение | `I don't see any use in **going** there.` | Не вижу смысла идти туда. |
| Обстоятельство | `He talked without **stopping**.` | Он говорил не останавливаясь. |

### Глаголы, после которых всегда герундий

`enjoy`, `finish`, `avoid`, `suggest`, `mind`, `keep`, `consider`, `admit`, `deny`, `practice`
`I enjoy **reading**.` | `She finished **writing** the letter.` | `Avoid **making** mistakes.`

---

## 📜 Причастие (Participle)

> Глагол в роли **прилагательного или деепричастия**.

### Таблица форм причастия

| Форма | Активный залог | Пассивный залог |
|---|---|---|
| Present Participle | **asking** (спрашивающий) | **being asked** (спрашиваемый) |
| Past Participle | — | **asked** (спрошенный) |
| Perfect Participle | **having asked** (спросив) | **having been asked** (будучи спрошенным) |

### Present Participle — одновременное действие

> `**Seeing** that I was late, I hurried.` — Видя, что опаздываю, я поторопился.
> `The girl **swimming** in the pool is my sister.` — Девочка, плывущая в бассейне — моя сестра.

### Past Participle — результат действия (пассив)

> `a building **built** many years ago` — здание, построенное много лет назад
> `the work **done** yesterday` — работа, выполненная вчера

### Perfect Participle — действие до основного

> `**Having asked** a question, the teacher waited for an answer.`
> Задав вопрос, учительница стала ждать ответа. (сначала задала, потом ждала)

---

## ⚡ Герундий vs Инфинитив

> [!WARNING] Некоторые глаголы меняют смысл!

| Глагол | + Герундий (-ing) | + Инфинитив (to) |
|---|---|---|
| `remember` | вспоминать прошлое: `I remember **meeting** him.` | не забыть сделать: `Remember **to call** her.` |
| `forget` | забыть о прошлом: `I forgot **telling** you.` | забыть сделать: `Don't forget **to lock** the door.` |
| `stop` | прекратить: `She stopped **smoking**.` | остановиться чтобы: `She stopped **to smoke**.` |
| `try` | пробовать (эксперимент): `Try **adding** salt.` | стараться: `Try **to be** on time.` |

### После `want`, `need`, `hope`, `decide`, `plan` → **инфинитив**
`I want **to learn** French.` | `She decided **to leave**.`

### После предлогов → **герундий**
`She's good **at cooking**.` | `I'm interested **in learning**.` | `Thank you **for helping**.`

---

## 🧠 Проверь себя

1. ___ (swim) is good exercise.
2. I remember ___ (see) him before.
3. The letter ___ (write) yesterday was important. (причастие)
4. She stopped ___ (talk) and looked at me.

<details>
<summary>👀 Ответы</summary>
1. Swimming is good exercise. (герундий-подлежащее)<br>
2. I remember seeing him before. (герундий после remember)<br>
3. The letter written yesterday was important. (Past Participle)<br>
4. She stopped talking. (прекратила говорить)
</details>

---

> [!CHECKBOX] ✅ Чеклист
> - [ ] Герундий = глагол как существительное (-ing)
> - [ ] После предлогов → всегда герундий
> - [ ] enjoy/finish/avoid/keep → герундий | want/decide/hope → инфинитив
> - [ ] Present Participle = одновременное действие
> - [ ] Past Participle = результат (пассивное значение)
> - [ ] Perfect Participle = действие до основного
