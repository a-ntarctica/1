# 📎 Союзы (Conjunctions)

## 🧭 Где мы?
[[../00_CORE/00_INDEX|← Индекс]] → **Дополнительно → Союзы**

---

## 📊 Сочинительные союзы (Coordinating)

> Соединяют **равноправные** части предложения или предложения между собой.

| Союз | Значение | Пример |
|---|---|---|
| **and** | и, а | `Kate goes to the park, and I go with her.` |
| **but** | но | `I looked everywhere, but couldn't find it.` |
| **or** | или | `Tea or coffee?` |
| **so** | поэтому, так что | `I'm not hungry, so no need for dinner.` |
| **for** | ибо, так как | `She took an umbrella, for it looked like rain.` |
| **yet** | тем не менее | `It's cold, yet she went outside.` |
| **still** | всё же | `He was tired, still he kept working.` |
| **both…and** | как…так и | `Both Kate and Nick were there.` |
| **either…or** | или…или | `Either go with me or stay here.` |
| **neither…nor** | ни…ни | `Neither he nor she knew the answer.` |
| **not only…but also** | не только…но и | `Not only fast but also accurate.` |
| **as well as** | так же как | `She speaks French as well as Spanish.` |

---

## 📊 Подчинительные союзы (Subordinating)

> Присоединяют **придаточные предложения** к главному.

### Время
| Союз | Значение | Пример |
|---|---|---|
| **when** | когда | `Call me when you arrive.` |
| **while** | пока, в то время как | `She sang while cooking.` |
| **before** | прежде чем | `Think before you speak.` |
| **after** | после того как | `After she left, I called.` |
| **until / till** | до тех пор пока не | `Wait until I come back.` |
| **as soon as** | как только | `I'll call as soon as I arrive.` |
| **since** | с тех пор как | `I haven't seen him since Monday.` |

### Условие
| Союз | Значение | Пример |
|---|---|---|
| **if** | если | `I'll help if you ask.` |
| **unless** | если не | `Unless you hurry, you'll be late.` |
| **provided (that)** | при условии что | `I'll come provided you invite me.` |

### Причина
| Союз | Значение | Пример |
|---|---|---|
| **because** | потому что | `I can't go because I'm busy.` |
| **since** | поскольку | `Since you're here, help me.` |
| **as** | так как | `As it was late, I left.` |

### Цель
| Союз | Значение | Пример |
|---|---|---|
| **so that** | чтобы | `Speak slowly so that I understand.` |
| **in order that** | с тем чтобы | `He worked hard in order to succeed.` |

### Уступка
| Союз | Значение | Пример |
|---|---|---|
| **although / though** | хотя | `Although it was cold, she went out.` |
| **even if** | даже если | `I'll go even if it rains.` |
| **no matter** | независимо от | `No matter what happens, stay calm.` |

### Сравнение
| Союз | Значение | Пример |
|---|---|---|
| **as…as** | такой же…как | `She's as tall as her sister.` |
| **as if / as though** | как будто | `He acts as if he owns the place.` |
| **than** | чем | `She runs faster than me.` |
| **the…the** | чем…тем | `The sooner, the better.` |

---

> [!CHECKBOX] ✅ Чеклист
> - [ ] Сочинительные: and/but/or/so/yet — равноправные части
> - [ ] either…or | neither…nor | both…and | not only…but also
> - [ ] Подчинительные времени: when/while/before/after/until/since
> - [ ] Подчинительные причины: because/since/as
> - [ ] although/though = уступка | as if = как будто
