# 📎 Числительные и дроби

## 🧭 Где мы?
[[../00_CORE/00_INDEX|← Индекс]] → **Дополнительно → Числительные**

---

## 📊 Количественные числительные (Cardinal)

| Число | Слово | Число | Слово |
|---|---|---|---|
| 1 | one | 11 | eleven |
| 2 | two | 12 | twelve |
| 3 | three | 13 | thirteen |
| 4 | four | 14 | fourteen |
| 5 | five | 15 | fifteen |
| 6 | six | 16 | sixteen |
| 7 | seven | 17 | seventeen |
| 8 | eight | 18 | eighteen |
| 9 | nine | 19 | nineteen |
| 10 | ten | 20 | twenty |

| Число | Слово | Число | Слово |
|---|---|---|---|
| 21 | twenty-one | 30 | thirty |
| 22 | twenty-two | 40 | forty |
| 100 | one hundred | 50 | fifty |
| 101 | one hundred and one | 60 | sixty |
| 200 | two hundred | 70 | seventy |
| 1 000 | one thousand | 80 | eighty |
| 1 000 000 | one million | 90 | ninety |

> [!NOTE] Правила чтения составных чисел
> `512` → five hundred **and** twelve
> `3 201` → three thousand, two hundred **and** one
> `1 050` → one thousand **and** fifty
> Между сотнями и десятками/единицами — всегда **and**

---

## 📊 Порядковые числительные (Ordinal)

| Число | Слово | Число | Слово |
|---|---|---|---|
| 1st | **first** | 11th | eleventh |
| 2nd | **second** | 12th | twelfth |
| 3rd | **third** | 13th | thirteenth |
| 4th | fourth | 20th | twentieth |
| 5th | fifth | 21st | twenty-**first** |
| 6th | sixth | 30th | thirtieth |
| 7th | seventh | 40th | fortieth |
| 8th | eighth | 100th | hundredth |
| 9th | ninth | 1000th | thousandth |
| 10th | tenth | | |

> [!WARNING] Неправильные формы — учить отдельно
> `one → first` | `two → second` | `three → third`
> `five → fifth` | `eight → eighth` | `nine → ninth` | `twelve → twelfth`

---

## 📊 Дроби и части

| Запись | Читается | Запись | Читается |
|---|---|---|---|
| ½ | a half | 2¼ | two and a quarter |
| ¼ | a quarter | ⅓ | one third |
| ⅕ | a/one fifth | ⅔ | two thirds |
| 1½ | one and a half | 2½ | two and a half |
| ⅒ | a/one tenth | 2⅐ | two and one-seventh |

> [!NOTE] Десятичные дроби
> В английском после целого числа ставится **точка**, не запятая:
> `3.45` → three point four five
> `0.75` → zero point seven five
> `34.75` → thirty-four point seven five

---

## 📌 Практические формулы

### Год
`1985` → nineteen eighty-five
`2024` → twenty twenty-four
`2000` → two thousand

### Телефон, адрес
Цифры читаются **по одной**: `0` = oh или zero
`+44 207 123 4567` → plus four four, two oh seven, one two three, four five six seven

### Этажи
`on the **first** floor` — на первом этаже
(в Британском English: 1st floor = 2-й этаж по-русски; ground floor = 1-й)

---

> [!CHECKBOX] ✅ Чеклист
> - [ ] 1–20 — выучить наизусть
> - [ ] first/second/third — неправильные порядковые
> - [ ] fifth/eighth/ninth/twelfth — осторожно с написанием
> - [ ] Дроби: ½=half, ¼=quarter, остальные = числитель + порядковый знаменатель
> - [ ] Десятичная точка, не запятая: 3.14 = three point one four
