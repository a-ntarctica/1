# 📎 Глагол GET — вектор действия

## 🧭 Где мы?
[[../00_CORE/00_INDEX|← Индекс]] → **Дополнительно → Глагол GET**

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 Запомни
> **GET** — один из самых частотных глаголов английского языка.
> Его суть: **движение к результату** или **изменение состояния**.
> Не пытайся найти одно русское слово — смотри на контекст.

---

## 📊 Основные значения GET

### 1. Получить / достать / добыть

> `I **got** a letter today.` — Я получил письмо сегодня.
> `Can you **get** me some water?` — Можешь принести мне воды?
> `Where did you **get** that jacket?` — Где ты взял эту куртку?

---

### 2. Стать / превратиться (изменение состояния)

> [!NOTE] GET + прилагательное = переход в новое состояние
> `It's **getting** cold.` — Становится холодно.
> `She **got** tired.` — Она устала.
> `He **got** angry.` — Он разозлился.
> `Don't **get** lost!` — Не заблудись!

| Русский | GET + прилагательное |
|---|---|
| жениться | get married |
| развестись | get divorced |
| заболеть | get sick / get ill |
| выздороветь | get better |
| устать | get tired |
| потеряться | get lost |
| одеться | get dressed |
| привыкнуть | get used to |

---

### 3. Добраться / прибыть

> `How do I **get** to the station?` — Как добраться до вокзала?
> `We **got** home late.` — Мы добрались домой поздно.
> `When did you **get** here?` — Когда ты сюда приехал?

---

### 4. Заставить / сделать так, чтобы

> **GET + дополнение + инфинитив** (с to)
> `I'll **get** him **to help** us.` — Я заставлю его помочь нам.
> `Can you **get** the car **to start**?` — Ты можешь завести машину?

> **GET + дополнение + причастие (Past Participle)** = организовать выполнение
> `I need to **get** my car **repaired**.` — Мне нужно отдать машину в ремонт.
> `She **got** her hair **cut**.` — Она постриглась.

---

### 5. Фразовые глаголы с GET

| Фраза | Значение | Пример |
|---|---|---|
| **get up** | вставать | `I get up at 7.` |
| **get on** | садиться (транспорт) / ладить | `Get on the bus.` / `We get on well.` |
| **get off** | выходить (транспорт) | `Get off at the next stop.` |
| **get in / into** | садиться (в машину) | `Get in the car.` |
| **get out (of)** | выходить (из машины) | `Get out of the car.` |
| **get back** | вернуться | `When did you get back?` |
| **get away** | сбежать, уехать | `We need to get away for a weekend.` |
| **get over** | оправиться, пережить | `She got over the illness quickly.` |
| **get through** | пробиться, справиться | `I can't get through to him.` |
| **get along (with)** | ладить с кем-то | `Do you get along with your boss?` |
| **get rid of** | избавиться от | `I need to get rid of old stuff.` |
| **get together** | собраться, встретиться | `Let's get together this weekend.` |
| **get across** | донести (идею) | `He couldn't get his point across.` |

---

## 💡 Почему GET так важен

> [!NOTE] Из транскрипта курса
> GET — это «глагол-вектор». Он показывает **направление** и **изменение**,
> тогда как `be` показывает **состояние**.
>
> `She **is** tired.` — она усталая (состояние сейчас)
> `She **got** tired.` — она **стала** уставшей (процесс изменения)
>
> Это различие — ключ к пониманию живого английского.

---

## 🧠 Проверь себя

Переведи:
1. Становится темно. → It's ___
2. Мне нужно постричься. → I need to ___
3. Как добраться до аэропорта? → How do I ___
4. Они хорошо ладят. → They ___

<details>
<summary>👀 Ответы</summary>
1. It's getting dark.<br>
2. I need to get my hair cut.<br>
3. How do I get to the airport?<br>
4. They get along well.
</details>

---

> [!CHECKBOX] ✅ Чеклист
> - [ ] get + прилагательное = изменение состояния (get tired, get married)
> - [ ] get to + место = добраться
> - [ ] get + объект + to do = заставить сделать
> - [ ] get + объект + Past Participle = организовать выполнение (get hair cut)
> - [ ] Фразовые глаголы: get up / get over / get rid of / get along
