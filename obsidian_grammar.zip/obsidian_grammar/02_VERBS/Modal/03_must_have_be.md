# 🎛️ must / have to / be to

## 🧭 Где мы?
[[../../00_CORE/00_INDEX|← Индекс]] → [[01_modal_overview|Модальные]] → **must / have to / be to**

---

## ✅ MUST

| Значение | Пример | Перевод |
|---|---|---|
| Обязанность (личное убеждение) | `You must talk to her.` | Ты должен с ней поговорить |
| Запрещение (must not) | `You must not leave.` | Тебе нельзя уходить |
| Уверенное предположение | `He must be 80 now.` | Ему, наверное, уже 80 |
| Эмоциональный совет | `You mustn't miss this!` | Ты не должен это пропустить! |

> [!WARNING] must не имеет формы прошедшего → заменяем на **had to**
> `I had to work late yesterday.` — Мне пришлось работать допоздна вчера.

---

## ✅ HAVE TO

| Значение | Пример | Перевод |
|---|---|---|
| Внешняя необходимость | `I have to wear a uniform.` | Мне приходится носить форму |
| Нет необходимости | `You don't have to come.` | Тебе не обязательно приходить |

| | Настоящее | Прошедшее | Будущее |
|---|---|---|---|
| ✅ | I have to go | I had to go | I will have to go |
| ❌ | I don't have to go | I didn't have to go | I won't have to go |
| ❓ | Do I have to go? | Did I have to go? | Will I have to go? |

---

## ✅ BE TO

| Значение | Пример | Перевод |
|---|---|---|
| По договорённости / плану | `We are to meet at 5.` | Мы договорились встретиться в 5 |
| Инструкция / приказ | `You are to report by Friday.` | Ты должен отчитаться до пятницы |
| Судьба (что суждено) | `He was to become famous.` | Ему было суждено стать знаменитым |

| | Настоящее | Прошедшее |
|---|---|---|
| ✅ | I am to go | I was to go |
| ❌ | I am not to go | I was not to go |

---

## 🧠 Проверь себя

1. Тебе не обязательно приходить рано.
2. Вчера мне пришлось остаться дома.
3. Мы договорились встретиться в понедельник.

<details>
<summary>👀 Ответы</summary>
1. You don't have to come early. | 2. I had to stay home yesterday. | 3. We are to meet on Monday.
</details>

---

→ [[04_should_will_need|should / will / need →]]

> [!CHECKBOX] ✅ Чеклист
> - [ ] must = личная обязанность | have to = внешняя необходимость
> - [ ] must not = запрещено | don't have to = не обязательно
> - [ ] must не имеет прошлого → had to
> - [ ] be to = по плану / договорённости
