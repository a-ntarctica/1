# 🎛️ Модальные глаголы — обзор

## 🧭 Где мы?
[[../../00_CORE/00_INDEX|← Индекс]] → **Модальные глаголы**

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 Запомни
> Модальные глаголы работают **так же, как русские**:
> «я могу» → `I can` | «я должен» → `I must` | «мне следует» → `I should`
>
> После модального → **инфинитив без to** (кроме: `have to`, `be to`, `ought to`)

---

## 📊 Все модальные одним взглядом

| Глагол | Значение | Пример |
|---|---|---|
| **can** | умею / могу / неформальное разрешение | `Can you swim?` |
| **could** | мог (прошлое) / вежливая просьба | `Could you help me?` |
| **may** | официальное разрешение / вероятность ~50% | `May I leave?` |
| **might** | слабая вероятность / упрёк | `He might be ill.` |
| **must** | личная обязанность / запрет / уверенность | `You must do it.` |
| **have to** | внешняя вынужденность | `I have to wear glasses.` |
| **be to** | по плану / договорённости | `We are to meet at 5.` |
| **should** | совет / лёгкий долг | `You should sleep more.` |
| **ought to** | моральная обязанность | `You ought to apologise.` |
| **will** | будущее / отказ / привычка | `She will sit there for hours.` |
| **would** | прошлая привычка / вежливость | `Would you like some tea?` |
| **need** | нет необходимости (вопросы/отрицания) | `You needn't hurry.` |
| **shall** | будущее I/We / предложение | `Shall we go?` |

---

## ⚡ Частые путаницы

> [!WARNING] must vs have to vs should
> - **must** — я сам считаю это важным: `You must see this film!`
> - **have to** — обстоятельства вынуждают: `I have to wear a uniform.`
> - **should** — совет, не жёсткое требование: `You should drink more water.`

> [!WARNING] must not vs don't have to
> - `You must not go.` — **запрещено** (нельзя)
> - `You don't have to go.` — **не обязательно** (но можно)

> [!WARNING] can vs may
> - **can** — способность: `I can speak French.`
> - **may** — разрешение (официально): `May I use your phone?`
> - В разговоре `can` часто заменяет `may` — это нормально

---

## 📌 Подробно по группам

→ [[02_can_may|can / could / may / might]]
→ [[03_must_have_be|must / have to / be to]]
→ [[04_should_will_need|should / will / ought to / need]]

---

> [!CHECKBOX] ✅ Чеклист
> - [ ] После модального → инфинитив без to
> - [ ] must ≠ have to (личное vs внешнее)
> - [ ] must not = запрещено | don't have to = не обязательно
