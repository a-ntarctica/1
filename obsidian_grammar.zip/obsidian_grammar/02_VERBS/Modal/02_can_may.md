# 🎛️ can / could / may / might

## 🧭 Где мы?
[[../../00_CORE/00_INDEX|← Индекс]] → [[01_modal_overview|Модальные]] → **can / may**

---

## ✅ CAN / COULD

| Значение | Пример | Перевод |
|---|---|---|
| Умение, способность | `Can you skate?` | Умеешь кататься? |
| Возможность | `You can see the forest from here.` | Отсюда можно увидеть лес |
| Разрешение (неформально) | `Can I use your car?` | Можно взять машину? |
| Сомнение | `Can it be true?` | Неужели это правда? |
| Невозможность | `It can't be true.` | Не может быть |

> [!NOTE] **could** = прошлое can или вежливая просьба
> `When I was young, I could run fast.` — раньше мог
> `Could you help me?` — вежливее, чем `Can you help me?`

| | ✅ | ❌ | ❓ |
|---|---|---|---|
| Настоящее | I can swim | I can't swim | Can I swim? |
| Прошедшее | I could swim | I couldn't swim | Could I swim? |

---

## ✅ MAY / MIGHT

| Значение | Пример | Перевод |
|---|---|---|
| Разрешение (официально) | `May I borrow your pen?` | Можно взять ручку? |
| Вероятность (~50%) | `He may be ill.` | Возможно, он болен |
| Пожелание | `May you be happy!` | Пусть ты будешь счастлив! |

> [!NOTE] **might** = слабая вероятность или упрёк
> `He might be ill.` — возможно болен (менее уверенно, чем may)
> `You might have helped me.` — ты бы мог помочь (но не помог)

---

## 🎯 Шкала вероятности

```
must be      ████████████ ~95%  — He must be at home.
may be       ██████       ~50%  — He may be at home.
might be     ███          ~30%  — He might be at home.
can't be     ░░░░░░░░░░░░  ~0%  — He can't be at home.
```

---

## 🧠 Проверь себя

1. ___ you play the guitar? (умеешь?)
2. ___ I open the window? (официальное разрешение)
3. She ___ be tired after such a long flight.

<details>
<summary>👀 Ответы</summary>
1. Can you play the guitar? | 2. May I open the window? | 3. She may/must be tired.
</details>

---

→ [[03_must_have_be|must / have to / be to →]]

> [!CHECKBOX] ✅ Чеклист
> - [ ] can = умение + неформальное разрешение
> - [ ] may = официальное разрешение + вероятность 50%
> - [ ] could / might = прошлое, вежливость, слабая вероятность
