# ⏱️ Continuous — Длительные времена

## 🧭 Где мы?
[[../../00_CORE/03_tense_map|← Карта времён]] | Ситуация: **Длительность** | Все три времени

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 Запомни
> Continuous = действие **в процессе** в конкретный момент.
> Формула: **be + глагол-ing**
> Меняем только `be` — и получаем нужное время.

---

## ⚙️ Формула

```
Present Continuous:  am/is/are  + глагол-ing
Past Continuous:     was/were   + глагол-ing
Future Continuous:   will be    + глагол-ing
```

---

## 📊 Present Continuous — сейчас, в данный момент

> `Mother is making dinner.` — Мама готовит обед (прямо сейчас).

| Кто? | ✅ | ❌ | ❓ |
|---|---|---|---|
| I | I **am** working | I **am not** working | **Am** I working? |
| He/She/It | He **is** working | He **isn't** working | **Is** he working? |
| You/We/They | They **are** working | They **aren't** working | **Are** they working? |

📌 Маркеры: `now`, `at the moment`, `right now`, `look!`, `listen!`

---

## 📊 Past Continuous — длилось в прошлом

> `I was writing when the bell rang.` — Я писал, когда позвонил звонок.

| Кто? | ✅ | ❌ | ❓ |
|---|---|---|---|
| I/He/She/It | I **was** working | I **wasn't** working | **Was** I working? |
| You/We/They | They **were** working | They **weren't** working | **Were** they working? |

📌 Маркеры: `at 5 o'clock yesterday`, `when + Past Simple`, `while`

> [!NOTE] Past Continuous vs Past Simple
> `I was reading when he called.` — читал (длилось), позвонил (момент)
> → длительное фоновое действие + прерывающий момент

---

## 📊 Future Continuous — будет длиться в будущем

> `I will be waiting for you at 9 o'clock tomorrow.` — Я буду ждать тебя завтра в 9.

| Кто? | ✅ | ❌ | ❓ |
|---|---|---|---|
| Все лица | I **will be** working | I **won't be** working | **Will** I **be** working? |

📌 Маркеры: `at this time tomorrow`, `at 8 p.m. tonight`

---

## 📌 Правила написания -ing

| Окончание глагола | Правило | Пример |
|---|---|---|
| Немая **-e** | убрать e → +ing | `write → writing` |
| Краткий слог + согл. | удвоить согл. → +ing | `run → running`, `sit → sitting` |
| Остальные | просто +ing | `work → working`, `play → playing` |

---

## ⚠️ Глаголы, которые НЕ используются в Continuous

> [!WARNING] Глаголы состояния (stative verbs) — без -ing!
> `know, understand, believe, love, hate, want, need, see, hear, smell, seem, belong`
>
> ✅ `I know the answer.` ❌ `I am knowing the answer.`

---

## 🧠 Проверь себя

1. She ___ (cook) dinner right now.
2. At 8 p.m. yesterday I ___ (watch) TV.
3. This time next week they ___ (fly) to Paris.

<details>
<summary>👀 Ответы</summary>
1. She is cooking dinner. | 2. I was watching TV. | 3. They will be flying to Paris.
</details>

---

→ [[07_present_perfect|Perfect →]] | → [[../../00_CORE/03_tense_map|← Карта времён]]

> [!CHECKBOX] ✅ Чеклист
> - [ ] Формула: be + -ing (am/is/are/was/were/will be)
> - [ ] Present: am/is/are | Past: was/were | Future: will be
> - [ ] Глаголы состояния — без Continuous
