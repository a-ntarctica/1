# ⏱️ Future Perfect — Будущее перфектное

## 🧭 Где мы?
[[../../00_CORE/03_tense_map|← Карта времён]] | Ситуация: **Опыт / Результат** | Время: **Будущее**

> [!NOTE] Все три Perfect времени описаны вместе:
> → [[07_present_perfect|Perfect — все три времени]]

---

## 📌 Быстрая шпаргалка

**Формула:** `will have + III форма глагола`

| Кто? | ✅ | ❌ | ❓ |
|---|---|---|---|
| Все лица | I **will have** written | I **won't have** written | **Will** I **have** written? |

**Когда:** действие завершится **к определённому моменту в будущем**.

> `By the time you arrive, I **will have finished** cooking.`
> К тому времени, как ты придёшь, я уже закончу готовить.

📌 Маркеры: `by tomorrow`, `by 5 o'clock`, `by the time`, `before`
