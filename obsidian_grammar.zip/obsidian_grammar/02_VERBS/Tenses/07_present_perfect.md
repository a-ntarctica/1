# ⏱️ Perfect — Опыт и результат

## 🧭 Где мы?
[[../../00_CORE/03_tense_map|← Карта времён]] | Ситуация: **Опыт / Результат** | Все три времени

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 Запомни
> Perfect = результат действия **важен** в определённый момент.
> Формула: **have/has/had/will have + III форма глагола**

---

## ⚙️ Формула

```
Present Perfect:  have/has        + III форма   → результат важен СЕЙЧАС
Past Perfect:     had             + III форма   → результат к моменту В ПРОШЛОМ
Future Perfect:   will have       + III форма   → результат к моменту В БУДУЩЕМ
```

---

## 📊 Present Perfect — результат важен сейчас

> `I have just bought this book.` — Я только что купил эту книгу (вот она!).
> `We have developed this project.` — Мы разработали этот проект (и он готов сейчас).

| Кто? | ✅ | ❌ | ❓ |
|---|---|---|---|
| I/You/We/They | I **have** written | I **haven't** written | **Have** I written? |
| He/She/It | He **has** written | He **hasn't** written | **Has** he written? |

📌 Маркеры: `just`, `already`, `yet`, `ever`, `never`, `recently`, `lately`, `since`, `for`

> [!WARNING] Present Perfect vs Past Simple
> `I have seen this film.` — видел (опыт, когда — неважно)
> `I saw this film yesterday.` — видел (факт прошлого, конкретное время)
> Если есть конкретное время → Past Simple. Если времени нет → Present Perfect.

---

## 📊 Past Perfect — результат к моменту в прошлом

> `She had just made coffee when I arrived.` — Она только что приготовила кофе, когда я пришёл.
> (сначала — приготовила, потом — я пришёл)

| Кто? | ✅ | ❌ | ❓ |
|---|---|---|---|
| Все лица | I **had** written | I **hadn't** written | **Had** I written? |

📌 Маркеры: `by the time`, `before`, `after`, `already`, `when (+ Past Simple)`

> [!NOTE] Past Perfect = «прошлое до прошлого»
> Действие 1 (Past Perfect) → Действие 2 (Past Simple)
> `When I arrived, she **had already left**.`

---

## 📊 Future Perfect — результат к моменту в будущем

> `She will have gone home by the time I arrive.` — Она уже уйдёт к тому времени, как я приду.

| Кто? | ✅ | ❌ | ❓ |
|---|---|---|---|
| I/We | I **shall/will have** written | I **won't have** written | **Will** I **have** written? |
| Остальные | You **will have** written | You **won't have** written | **Will** you **have** written? |

📌 Маркеры: `by tomorrow`, `by the time`, `by 5 o'clock`, `before`

---

## 🧠 Проверь себя

1. I ___ (already/eat). I'm not hungry.
2. When she arrived, he ___ (already/leave).
3. By next Monday they ___ (finish) the report.

<details>
<summary>👀 Ответы</summary>
1. I have already eaten. | 2. He had already left. | 3. They will have finished.
</details>

---

→ [[10_perfect_continuous|Perfect Continuous →]] | → [[../../00_CORE/03_tense_map|← Карта времён]]

> [!CHECKBOX] ✅ Чеклист
> - [ ] have/has + III форма → результат сейчас (Present Perfect)
> - [ ] had + III форма → результат до прошлого (Past Perfect)
> - [ ] will have + III форма → результат к будущему моменту
> - [ ] Конкретное время → Past Simple, нет времени → Present Perfect
