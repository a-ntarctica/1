# ⏱️ Future Continuous — Будущее длительное

## 🧭 Где мы?
[[../../00_CORE/03_tense_map|← Карта времён]] | Ситуация: **Длительность** | Время: **Будущее**

> [!NOTE] Все три Continuous времени описаны вместе:
> → [[04_present_continuous|Continuous — все три времени]]

---

## 📌 Быстрая шпаргалка

**Формула:** `will be + глагол-ing`

| Кто? | ✅ | ❌ | ❓ |
|---|---|---|---|
| Все лица | I **will be** working | I **won't be** working | **Will** I **be** working? |

**Когда:** действие будет длиться в конкретный момент будущего.

> `At this time tomorrow I **will be flying** to London.`
> Завтра в это время я буду лететь в Лондон.

📌 Маркеры: `at this time tomorrow`, `at 8 p.m. tonight`, `this time next week`
