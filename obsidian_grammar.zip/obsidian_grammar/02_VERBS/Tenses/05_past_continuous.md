# ⏱️ Past Continuous — Прошедшее длительное

## 🧭 Где мы?
[[../../00_CORE/03_tense_map|← Карта времён]] | Ситуация: **Длительность** | Время: **Прошлое**

> [!NOTE] Все три Continuous времени описаны вместе:
> → [[04_present_continuous|Continuous — все три времени]]

---

## 📌 Быстрая шпаргалка

**Формула:** `was/were + глагол-ing`

| Кто? | ✅ | ❌ | ❓ |
|---|---|---|---|
| I/He/She/It | I **was** working | I **wasn't** working | **Was** I working? |
| You/We/They | They **were** working | They **weren't** working | **Were** they working? |

**Когда:** действие длилось в прошлом, часто прерывается другим действием (Past Simple).

> `I **was reading** when he **called**.`
> Я читал (длилось), когда он позвонил (прервал).

📌 Маркеры: `at 5 yesterday`, `when…`, `while…`, `all morning`
