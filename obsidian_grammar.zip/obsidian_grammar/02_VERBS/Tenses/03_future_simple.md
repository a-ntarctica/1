# ⏱️ Future Simple — Будущее простое

## 🧭 Где мы?
[[../../00_CORE/03_tense_map|← Карта времён]] | Ситуация: **Действие** | Время: **Будущее**

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 Запомни
> Добавляем **will** перед базовой формой глагола — для всех лиц одинаково.
>
> `I will play.` — Я буду играть.
> `She will play.` — Она будет играть.

---

## 📜 Образование

> [!WARNING] Утверждение → **will** + базовая форма
> `I will play` | `She will go` | сокращение: `I'll play`

> [!WARNING] Отрицание → **will not (won't)** + базовая форма
> `I won't play` | `He will not come`

> [!WARNING] Вопрос → **Will** + подлежащее + базовая форма
> `Will you play?` | `Will she come?`

---

## 📊 Таблица форм

| Кто? | ✅ | ❌ | ❓ |
|---|---|---|---|
| I | I **will** play | I **won't** play | **Will** I play? |
| You | You will play | You won't play | Will you play? |
| He/She/It | He will play | He won't play | Will he play? |
| We/They | We will play | We won't play | Will we play? |

---

## 📌 Когда использовать

| Случай | Пример |
|---|---|
| Спонтанное решение | `I'll help you.` — (решил прямо сейчас) |
| Предсказание / мнение | `I think it will rain.` |
| Обещание | `I will call you.` |
| Факт о будущем | `She will be 30 next year.` |

> [!NOTE] **will vs going to**
> `will` — спонтанное решение или предсказание без доказательств
> `going to` — запланированное действие или очевидное предсказание
> `I'm going to visit Paris next month.` — уже запланировано

---

## ⚠️ Важно: после if / when / until — Present Simple!

> [!WARNING]
> В придаточных условия и времени **will не используется**:
> ✅ `I will call you when I **arrive**.`
> ❌ `I will call you when I will arrive.`
> → [[../../06_SPEECH/03_conditional|Условные предложения]]

---

## 🧠 Проверь себя

1. I ___ (help) you tomorrow.
2. She ___ (not/come) to the party.
3. ___ they ___ (finish) the project by Friday?

<details>
<summary>👀 Ответы</summary>
1. I will help you. | 2. She won't come. | 3. Will they finish?
</details>

---

→ [[02_past_simple|← Past Simple]] | → [[04_present_continuous|Present Continuous →]]

> [!CHECKBOX] ✅ Чеклист
> - [ ] will + базовая форма для всех лиц
> - [ ] won't = will not
> - [ ] После if/when → Present Simple, не will
