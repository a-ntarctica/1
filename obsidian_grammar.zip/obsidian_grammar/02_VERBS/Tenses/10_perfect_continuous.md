# ⏱️ Perfect Continuous — Длительность + Результат

## 🧭 Где мы?
[[../../00_CORE/03_tense_map|← Карта времён]] | Ситуация: **Длит. + Результат**

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 Запомни
> Perfect Continuous = действие **началось в прошлом и всё ещё длится** (или только что закончилось, и это ощущается).
> Формула: **have/has/had/will have + been + глагол-ing**

---

## ⚙️ Формула

```
Present Perfect Continuous:  have/has been  + глагол-ing
Past Perfect Continuous:     had been       + глагол-ing
Future Perfect Continuous:   will have been + глагол-ing
```

---

## 📊 Present Perfect Continuous

> `I have been waiting for you for 4 hours.` — Я жду тебя уже 4 часа (и всё ещё жду).

| Кто? | ✅ | ❌ | ❓ |
|---|---|---|---|
| I/You/We/They | I **have been** working | I **haven't been** working | **Have** I **been** working? |
| He/She/It | He **has been** working | He **hasn't been** working | **Has** he **been** working? |

📌 Маркеры: `for` (в течение), `since` (с тех пор как), `all day/morning`

> [!NOTE] **for vs since**
> `for 2 hours` — продолжительность (сколько длится)
> `since Monday` — точка отсчёта (с какого момента)

---

## 📊 Past Perfect Continuous

> `When you came, I had already been waiting for 2 hours.`
> Когда ты пришёл, я уже ждал 2 часа.

| Кто? | ✅ | ❌ | ❓ |
|---|---|---|---|
| Все лица | I **had been** working | I **hadn't been** working | **Had** I **been** working? |

---

## 📊 Future Perfect Continuous

> `By next week you will have been studying here for 4 months.`
> На следующей неделе исполнится 4 месяца, как ты здесь учишься.

| Кто? | ✅ | ❌ | ❓ |
|---|---|---|---|
| Все лица | I **will have been** working | I **won't have been** working | **Will** I **have been** working? |

---

## 🧠 Проверь себя

1. She ___ (work) here for 10 years. (и сейчас работает)
2. He ___ (sleep) for 3 hours when I woke him up.

<details>
<summary>👀 Ответы</summary>
1. She has been working here for 10 years. | 2. He had been sleeping for 3 hours.
</details>

---

> [!CHECKBOX] ✅ Чеклист
> - [ ] have/has been + -ing → длится и сейчас / только что закончилось
> - [ ] for = сколько длится | since = с какого момента
> - [ ] had been + -ing → длилось до момента в прошлом
