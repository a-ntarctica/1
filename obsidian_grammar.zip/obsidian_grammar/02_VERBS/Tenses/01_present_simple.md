# ⏱️ Present Simple — Настоящее простое

## 🧭 Где мы?
[[../../00_CORE/03_tense_map|← Карта времён]] | Ситуация: **Действие** | Время: **Настоящее**

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 Запомни
> Говорим о том, что происходит **регулярно, всегда, как факт** — но не прямо сейчас.
> `I go to school every day.` — Я хожу в школу каждый день.

---

## 📜 Образование

> [!WARNING] Утверждение
> I/You/We/They → базовая форма глагола
> He/She/It → глагол **+s** (или -es, -ies)
>
> `I work` | `She work**s**` | `He teach**es**` | `She stud**ies**`

> [!WARNING] Отрицание → **don't / doesn't** + базовая форма
> `I **don't** work` | `She **doesn't** work`
> ❌ `She doesn't work**s**` — ошибка!

> [!WARNING] Вопрос → **Do / Does** + подлежащее + базовая форма
> `**Do** you work?` | `**Does** she work?`

---

## 📊 Таблица форм

| Кто? | ✅ | ❌ | ❓ |
|---|---|---|---|
| I | I work | I don't work | Do I work? |
| You | You work | You don't work | Do you work? |
| He/She/It | He work**s** | He doesn't work | Does he work? |
| We/They | We work | We don't work | Do we work? |

---

## 📌 Когда использовать

| Случай | Маркеры времени |
|---|---|
| Привычка / регулярное действие | always, usually, often, sometimes, never, every day/week |
| Факт, общая истина | — |
| Расписание (поезд, самолёт) | — |
| После if/when/until в будущем | `Call me when you arrive.` |

---

## 🧠 Проверь себя

1. He ___ (go) to work by bus.
2. They ___ (not/like) cold weather.
3. ___ she ___ (speak) French?

<details>
<summary>👀 Ответы</summary>
1. He goes | 2. They don't like | 3. Does she speak?
</details>

---

→ [[02_past_simple|Past Simple →]] | → [[04_present_continuous|Present Continuous →]]

> [!CHECKBOX] ✅ Чеклист
> - [ ] He/She/It → +s в утверждении
> - [ ] Отрицание: don't / doesn't + базовый глагол
> - [ ] Вопрос: Do / Does + подлежащее + базовый глагол
