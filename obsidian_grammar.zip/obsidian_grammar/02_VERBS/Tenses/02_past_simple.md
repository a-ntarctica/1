# ⏱️ Past Simple — Прошедшее простое

## 🧭 Где мы?
[[../../00_CORE/03_tense_map|← Карта времён]] | Ситуация: **Действие** | Время: **Прошлое**

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 Запомни
> Действие **завершилось в прошлом** и не связано с настоящим.
> Часто есть указание на время: yesterday, last week, in 2010.
>
> `I wrote a letter yesterday.` — Я написал письмо вчера.

---

## 📜 Образование

> [!WARNING] Утверждение
> Правильный глагол → **+ed** | Неправильный → **II форма**
> Форма одинакова для всех лиц — нет +s!
>
> `I played` | `She played` | `He went` | `They saw`

> [!WARNING] Отрицание → **didn't** + базовая форма
> `I **didn't** play`
> ❌ `I didn't played` — ошибка! Два показателя прошлого

> [!WARNING] Вопрос → **Did** + подлежащее + базовая форма
> `**Did** you play?`
> ❌ `Did you played?` — ошибка!

---

## 📊 Таблица форм

| Кто? | ✅ | ❌ | ❓ |
|---|---|---|---|
| I | I play**ed** | I didn't play | Did I play? |
| You | You played | You didn't play | Did you play? |
| He/She/It | He played | He didn't play | Did he play? |
| We/They | We played | We didn't play | Did we play? |

---

## 📌 Маркеры прошедшего

`yesterday` | `last week/month/year` | `ago` (`two days ago`) | `in 2010` | `just now` | `when I was young`

---

## ⚙️ Связь с механизмом DO

> [!NOTE] Логика через DO
> `I do play` → эмфаза в настоящем
> `I did play` → эмфаза в прошлом → убираем `did` в конец → `I play**ed**`
> Именно так appeared окончание -ed: `did` «ушёл» в конец глагола.
> → [[../../00_CORE/02_do_engine|Механизм DO]]

---

## 🧠 Проверь себя

1. She ___ (not/work) yesterday.
2. ___ you ___ (play) football last Saturday?
3. They ___ (cook) dinner together. (cook — правильный)

<details>
<summary>👀 Ответы</summary>
1. She didn't work yesterday. | 2. Did you play football? | 3. They cooked dinner.
</details>

---

→ [[01_present_simple|← Present Simple]] | → [[03_future_simple|Future Simple →]]

> [!CHECKBOX] ✅ Чеклист
> - [ ] Утверждение: +ed или II форма (без разницы кто)
> - [ ] Отрицание/вопрос: didn't / Did + базовая форма
> - [ ] Маркеры: yesterday, ago, last…
