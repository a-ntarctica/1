# 🔧 Правильные и неправильные глаголы

## 🧭 Где мы?
[[../../00_CORE/00_INDEX|← Индекс]] → **Глаголы → Формы**

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 У каждого глагола 3 формы
> **I форма** — инфинитив (базовая)
> **II форма** — прошедшее время (Past Simple)
> **III форма** — причастие прошедшего (для Perfect и Passive)

---

## 📜 Правильные глаголы → **+ed**

| Условие | Правило | Пример |
|---|---|---|
| Обычно | **+ed** | `work → worked` |
| На **-e** | **+d** | `live → lived` |
| Согласная + **-y** | **-y → -ied** | `study → studied` |
| Гласная + **-y** | **+ed** | `stay → stayed` |
| Краткий слог + согл. | **удвоить + ed** | `stop → stopped` |

---

## 📜 Неправильные глаголы

### Группа A: Все три формы разные
| I | II | III | Перевод |
|---|---|---|---|
| be | was/were | been | быть |
| begin | began | begun | начинать |
| blow | blew | blown | дуть |
| break | broke | broken | ломать |
| choose | chose | chosen | выбирать |
| do | did | done | делать |
| draw | drew | drawn | рисовать |
| drink | drank | drunk | пить |
| drive | drove | driven | вести машину |
| eat | ate | eaten | есть |
| fall | fell | fallen | падать |
| fly | flew | flown | летать |
| forget | forgot | forgotten | забывать |
| give | gave | given | давать |
| go | went | gone | идти |
| grow | grew | grown | расти |
| hide | hid | hidden | прятать |
| know | knew | known | знать |
| ride | rode | ridden | ехать верхом |
| rise | rose | risen | подниматься |
| see | saw | seen | видеть |
| shake | shook | shaken | трясти |
| sing | sang | sung | петь |
| speak | spoke | spoken | говорить |
| steal | stole | stolen | красть |
| swim | swam | swum | плавать |
| take | took | taken | брать |
| throw | threw | thrown | бросать |
| wear | wore | worn | носить |
| write | wrote | written | писать |

### Группа B: II = III форма
| I | II = III | Перевод |
|---|---|---|
| bring | brought | приносить |
| build | built | строить |
| buy | bought | покупать |
| catch | caught | ловить |
| feel | felt | чувствовать |
| fight | fought | бороться |
| find | found | находить |
| have | had | иметь |
| hear | heard | слышать |
| hold | held | держать |
| keep | kept | хранить |
| leave | left | оставлять |
| lose | lost | терять |
| make | made | делать |
| mean | meant | значить |
| meet | met | встречать |
| say | said | сказать |
| sell | sold | продавать |
| send | sent | посылать |
| sit | sat | сидеть |
| sleep | slept | спать |
| spend | spent | тратить |
| stand | stood | стоять |
| teach | taught | обучать |
| tell | told | сказать |
| think | thought | думать |
| understand | understood | понимать |
| win | won | выигрывать |

### Группа C: Все три формы одинаковые
| I = II = III | Перевод |
|---|---|
| cost | стоить |
| cut | резать |
| hurt | болеть |
| let | позволять |
| put | класть |
| read* | читать *[riːd]→[red] |
| run | бежать |
| spread | распространять |

---

## 🧠 Проверь себя

Напиши три формы:
1. go → ___ → ___ | 2. write → ___ → ___ | 3. buy → ___ → ___

<details>
<summary>👀 Ответы</summary>
1. go → went → gone | 2. write → wrote → written | 3. buy → bought → bought
</details>

---

> [!CHECKBOX] ✅ Чеклист
> - [ ] Правильные: +ed (+ правила написания)
> - [ ] Группа A: go/went/gone, see/saw/seen, write/wrote/written
> - [ ] Группа B: buy/bought/bought, have/had/had, think/thought/thought
> - [ ] Группа C: cut/cut/cut, put/put/put
