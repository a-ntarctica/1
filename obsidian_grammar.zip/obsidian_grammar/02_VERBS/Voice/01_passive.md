# 🔄 Passive Voice — Страдательный залог

## 🧭 Где мы?
[[../../00_CORE/00_INDEX|← Индекс]] → **Глаголы → Залог**

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 Запомни
> **Active:** Петя разбил окно. → `Pete broke the window.`
> **Passive:** Окно было разбито Петей. → `The window was broken by Pete.`
>
> Используем Passive, когда **действие важнее того, кто его совершил**.
> Формула: **be (нужная форма) + III форма глагола**

---

## ⚙️ Формула по временам

| Время | Формула | Пример |
|---|---|---|
| Present Simple | am/is/are + III | `The room is cleaned every day.` |
| Past Simple | was/were + III | `The letter was written yesterday.` |
| Future Simple | will be + III | `The report will be sent tomorrow.` |
| Present Continuous | am/is/are being + III | `The car is being repaired now.` |
| Past Continuous | was/were being + III | `The road was being built last year.` |
| Present Perfect | have/has been + III | `The work has been done.` |
| Past Perfect | had been + III | `The letter had been sent before she arrived.` |
| Future Perfect | will have been + III | `The project will have been finished by Monday.` |

---

## 📊 Полная таблица форм

| | ✅ Утверждение | ❌ Отрицание | ❓ Вопрос |
|---|---|---|---|
| Present | I **am asked** | I **am not** asked | **Am** I asked? |
| Past | I **was asked** | I **was not** asked | **Was** I asked? |
| Future | I **will be** asked | I **won't be** asked | **Will** I **be** asked? |
| Pres. Perfect | I **have been** asked | I **haven't been** asked | **Have** I **been** asked? |

---

## 📌 Важные детали

> [!NOTE] Кто совершил действие — указываем через **by**
> `The window was broken **by Pete**.`
> `This book was written **by Tolstoy**.`
> Если исполнитель неважен или неизвестен — `by` можно опустить:
> `The letter was sent.` — Письмо отправили.

> [!WARNING] Особенность английского Passive
> В русском языке косвенное дополнение **не может** стать подлежащим.
> В английском — **может**:
>
> `I gave him a book.`
> → `He was given a book.` ✅ (косвенное дополнение стало подлежащим)
> → `A book was given to him.` ✅ (прямое дополнение стало подлежащим)

---

## 🧠 Проверь себя

Переведи в Passive:
1. They clean the office every day. → ___
2. Someone stole my bag. → ___
3. They will finish the project next week. → ___

<details>
<summary>👀 Ответы</summary>
1. The office is cleaned every day.<br>
2. My bag was stolen.<br>
3. The project will be finished next week.
</details>

---

> [!CHECKBOX] ✅ Чеклист
> - [ ] Формула: be (нужная форма) + III форма
> - [ ] Исполнитель → by + существительное
> - [ ] В английском косвенное дополнение может стать подлежащим
