# 📚 База знаний: Грамматика английского языка

> [!TIP] 💡 Философия этой базы
> Английский — один из самых лёгких языков. Всего **4 типа ситуаций × 3 времени = 12 структур**.
> Пойми логику — и язык откроется сам.

---

## 🧭 С чего начать?

→ [[01_four_situations|4 ситуации — основа всего]]
→ [[02_do_engine|Механизм DO — как работает глагол]]
→ [[03_tense_map|Карта всех 12 времён]]

---

## 🗂️ Разделы базы

### 📦 Существительные
| Файл | Тема |
|---|---|
| [[../01_NOUNS/01_plural\|Множественное число]] | dog→dogs, child→children |
| [[../01_NOUNS/02_articles\|Артикли a / the / —]] | когда что ставить |

### 🔧 Глаголы — формы
| Файл | Тема |
|---|---|
| [[../02_VERBS/01_regular_irregular\|Правильные и неправильные]] | +ed vs II форма |

### ⏱️ Глаголы — времена
| Файл | Тема |
|---|---|
| [[../02_VERBS/Tenses/01_present_simple\|Present Simple]] | I play — обычное действие |
| [[../02_VERBS/Tenses/02_past_simple\|Past Simple]] | I played — прошлое |
| [[../02_VERBS/Tenses/03_future_simple\|Future Simple]] | I will play — будущее |
| [[../02_VERBS/Tenses/04_present_continuous\|Present Continuous]] | I am playing — прямо сейчас |
| [[../02_VERBS/Tenses/05_past_continuous\|Past Continuous]] | I was playing — длилось в прошлом |
| [[../02_VERBS/Tenses/06_future_continuous\|Future Continuous]] | I will be playing — будет длиться |
| [[../02_VERBS/Tenses/07_present_perfect\|Present Perfect]] | I have played — опыт / результат |
| [[../02_VERBS/Tenses/08_past_perfect\|Past Perfect]] | I had played — до момента в прошлом |
| [[../02_VERBS/Tenses/09_future_perfect\|Future Perfect]] | I will have played — к моменту в будущем |
| [[../02_VERBS/Tenses/10_perfect_continuous\|Perfect Continuous]] | I have been playing — длится с прошлого |

### 🎛️ Модальные глаголы
| Файл | Тема |
|---|---|
| [[../02_VERBS/Modal/01_modal_overview\|Обзор]] | все модальные одним взглядом |
| [[../02_VERBS/Modal/02_can_may\|can / could / may / might]] | умею / разрешение / вероятность |
| [[../02_VERBS/Modal/03_must_have_be\|must / have to / be to]] | должен / вынужден / по плану |
| [[../02_VERBS/Modal/04_should_will_need\|should / will / ought to / need]] | совет / будущее / необходимость |

### 🔄 Залог
| Файл | Тема |
|---|---|
| [[../02_VERBS/Voice/01_passive\|Passive Voice]] | окно разбито / the window was broken |

### 👤 Местоимения
| Файл | Тема |
|---|---|
| [[../03_PRONOUNS/01_personal\|Личные и притяжательные]] | I/me/my/mine |
| [[../03_PRONOUNS/02_indefinite\|Неопределённые]] | some / any / every / no |
| [[../03_PRONOUNS/03_other\|Указательные и вопросительные]] | this/that/who/which |

### 🎨 Сравнение
| Файл | Тема |
|---|---|
| [[../04_ADJECTIVES/01_comparison\|Степени сравнения]] | big → bigger → biggest |

### ❓ Вопросы
| Файл | Тема |
|---|---|
| [[../05_QUESTIONS/01_question_types\|Типы вопросов]] | общий / специальный / к субъекту |
| [[../05_QUESTIONS/02_negative_questions\|Вопросы через отрицание]] | Don't you…? / Why isn't…? |

### 💬 Речь и структура
| Файл | Тема |
|---|---|
| [[../06_SPEECH/01_reported_speech\|Косвенная речь]] | He said that… |
| [[../06_SPEECH/02_sequence_of_tenses\|Согласование времён]] | правило сдвига |
| [[../06_SPEECH/03_conditional\|Условное наклонение]] | If I were you… |

### 📎 Дополнительно
| Файл | Тема |
|---|---|
| [[../07_OTHER/01_conjunctions\|Союзы]] | and / but / because / if… |
| [[../07_OTHER/02_numerals\|Числительные и дроби]] | one/first/a half |
| [[../07_OTHER/03_gerund_participle\|Герундий и причастие]] | swimming / having asked |
| [[../07_OTHER/04_get_verb\|Глагол GET]] | вектор действия |
