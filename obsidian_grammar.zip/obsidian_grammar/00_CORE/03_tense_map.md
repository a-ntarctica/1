# 🗺️ Карта всех 12 времён

## 🧭 Где мы?
[[00_INDEX|← Индекс]] → [[01_four_situations|4 ситуации]] → **Карта времён**

---

## 🎯 Главное за 10 секунд

> [!TIP] 💡 12 времён = 4 ситуации × 3 времени
> Не учи их по одному — видь всю систему сразу.

---

## 📊 Полная карта

|  | 🕐 Прошлое | 🕑 Настоящее | 🕒 Будущее |
|---|---|---|---|
| **1. Действие** | `I played` | `I play` | `I will play` |
| *(Simple / Indefinite)* | [[../02_VERBS/Tenses/02_past_simple\|Past Simple]] | [[../02_VERBS/Tenses/01_present_simple\|Present Simple]] | [[../02_VERBS/Tenses/03_future_simple\|Future Simple]] |
| **2. Длительность** | `I was playing` | `I am playing` | `I will be playing` |
| *(Continuous)* | [[../02_VERBS/Tenses/05_past_continuous\|Past Continuous]] | [[../02_VERBS/Tenses/04_present_continuous\|Present Continuous]] | [[../02_VERBS/Tenses/06_future_continuous\|Future Continuous]] |
| **3. Опыт / результат** | `I had played` | `I have played` | `I will have played` |
| *(Perfect)* | [[../02_VERBS/Tenses/08_past_perfect\|Past Perfect]] | [[../02_VERBS/Tenses/07_present_perfect\|Present Perfect]] | [[../02_VERBS/Tenses/09_future_perfect\|Future Perfect]] |
| **4. Длит. + результат** | `I had been playing` | `I have been playing` | `I will have been playing` |
| *(Perfect Continuous)* | [[../02_VERBS/Tenses/10_perfect_continuous\|Past Perf. Cont.]] | [[../02_VERBS/Tenses/10_perfect_continuous\|Pres. Perf. Cont.]] | [[../02_VERBS/Tenses/10_perfect_continuous\|Fut. Perf. Cont.]] |

---

## 🔑 Формулы образования

> [!NOTE] Как собрать любое время

```
Simple:             подл. + (do/did/will) + глагол
Continuous:         подл. + be (am/is/are/was/were/will be) + глагол-ing
Perfect:            подл. + have/has/had/will have + глагол III форма
Perfect Continuous: подл. + have/has/had/will have + been + глагол-ing
```

---

## 💡 Как выбрать нужное время

```
Действие завершилось и НЕ важно когда?
    → Simple (played / have played)

Действие было В ПРОЦЕССЕ в конкретный момент?
    → Continuous (was playing / am playing)

Результат важен СЕЙЧАС?
    → Present Perfect (have played)

Действие завершилось ДО другого момента в прошлом?
    → Past Perfect (had played)

Действие длится С какого-то момента И ВСЁ ЕЩЁ идёт?
    → Perfect Continuous (have been playing)
```

---

## 🔗 Быстрый переход
→ [[../02_VERBS/Tenses/01_present_simple|Present Simple]]
→ [[../02_VERBS/Tenses/02_past_simple|Past Simple]]
→ [[../02_VERBS/Tenses/07_present_perfect|Present Perfect]]
→ [[../02_VERBS/Tenses/04_present_continuous|Present Continuous]]
